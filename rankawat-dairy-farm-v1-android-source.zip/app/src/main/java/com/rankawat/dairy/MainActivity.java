package com.rankawat.dairy;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.graphics.Color;
public class MainActivity extends Activity{
 WebView w;
 public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);w.setBackgroundColor(Color.WHITE);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);w.loadUrl("file:///android_asset/index.html");setContentView(w);}
 @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}